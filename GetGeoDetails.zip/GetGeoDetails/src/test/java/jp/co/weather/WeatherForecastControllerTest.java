package jp.co.weather;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import jp.co.weather.entity.AirPollution;
import jp.co.weather.entity.DailyWeatherList;
import jp.co.weather.entity.GeoLocation;
import jp.co.weather.entity.MapResults;



/**
 *  Unit test for controller layer through MockMvc and TestRestTemplate
 *
 */
@RunWith(SpringRunner.class)
@AutoConfigureJsonTesters
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class WeatherForecastControllerTest {
	
	private GeoLocation geoLocation;

	private MockMvc mockMvc;
	
	@Autowired
	private TestRestTemplate testRestTemplate;

	
	@Autowired
	private WebApplicationContext webApplicationContext;

	
	@Before
	public void setup() {
		// @formatter:off
		geoLocation = GeoLocation.builder()
					.postCode("170-0012")
					.zip("170-0012")
					.name("Kamiikebukuro")
					.country("JP")
					.build();		
		// @formatter:off
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		
	}
	
	
	@Test	
	public final void getZipCodeInfoTest() throws Exception {
		MvcResult geoResponse = mockMvc.perform(get("/")
				.contentType(MediaType.APPLICATION_JSON)).andReturn();
		assertTrue(geoResponse.getResponse().getStatus() == HttpStatus.OK.value());		
	}
	
	@Test	
	public final void getWeatherInfoTest() throws Exception {
		MvcResult geoResponse = mockMvc.perform(post("/")
				.contentType(MediaType.APPLICATION_JSON)).andReturn();
		assertTrue(geoResponse.getResponse().getStatus() == HttpStatus.OK.value());		
	}
	
	
	@Test	
	public final void getLocationDetailsBasedOnZIPTest() throws Exception {		
		URI uri = new URI("https://api.openweathermap.org/geo/1.0/zip?zip=170-0012,JP&appid=8905fafcea1582322acccf1af9fa75ad");
		GeoLocation actualLocation = testRestTemplate.getForObject(uri, GeoLocation.class);
		assertTrue(actualLocation.getZip().equals(geoLocation.getZip()));
		assertTrue(actualLocation.getName().equals(geoLocation.getName()));	
		assertTrue(actualLocation.getCountry().equals(geoLocation.getCountry()));
	}
	
	
	@Test	
	public final void getDailyWeatherBasedOnLocationTest() throws Exception {
		URI uri = new URI("https://api.openweathermap.org/data/2.5/onecall?lat=35.73&lon=139.71&exclude=current,minutely,hourly,alerts&appid=8905fafcea1582322acccf1af9fa75ad");
		DailyWeatherList actualDailyWeatherList = testRestTemplate.getForObject(uri, DailyWeatherList.class);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd EEE", Locale.ENGLISH);
		assertTrue(actualDailyWeatherList.getDaily().get(0).getDate().equals(sdf.format(Calendar.getInstance().getTime())));
		assertTrue(!actualDailyWeatherList.getDaily().get(0).getWeather().get(0).getMain().equals(""));
	}
	
	@Test	
	public final void getMapBasedOnLocationTest() throws Exception {
		URI uri = new URI("http://www.mapquestapi.com/geocoding/v1/address?key=oygAk3HMuycqZrTe2iuI8aGYmou5jpAd&location=170-0012+Kamiikebukuro");
		MapResults mapResults = testRestTemplate.getForObject(uri, MapResults.class);
		assertTrue(!mapResults.getResults().get(0).getLocations().get(0).getMapUrl().equals(""));
		assertTrue(mapResults.getResults().get(0).getLocations().get(0).getAdminArea5().equals("Toshima"));
		assertTrue(mapResults.getResults().get(0).getLocations().get(0).getAdminArea3().equals("Tokyo"));
	}
	
	@Test	
	public final void getCurrentAirPollutionBasedOnLocationTest() throws Exception {
		URI uri = new URI("http://api.openweathermap.org/data/2.5/air_pollution?lat=35.7381&lon=139.7195&appid=8905fafcea1582322acccf1af9fa75ad");
		AirPollution airPollution = testRestTemplate.getForObject(uri, AirPollution.class);
		assertTrue(airPollution.getList().size() >= 1);
	}
		
}
