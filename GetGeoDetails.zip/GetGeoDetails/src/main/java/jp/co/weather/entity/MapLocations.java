package jp.co.weather.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for map details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class MapLocations {
	@Id
	private String mapUrl;
	private String adminArea5;
	private String adminArea5Type;
	private String adminArea3;
}
