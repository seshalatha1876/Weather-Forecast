package jp.co.weather.exception;

/**
 * GeneralRestException to handle handle rest client exceptions, HTTP status exceptions and bad requests
 * 
 * @author sesha
 * 
 */

public class GeneralRestException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public GeneralRestException(String message){
		super(message);		
	}
}