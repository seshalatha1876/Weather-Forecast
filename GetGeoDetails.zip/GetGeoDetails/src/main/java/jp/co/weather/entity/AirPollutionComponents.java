package jp.co.weather.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

/**
 * Entity for air components
 * 
 * @author sesha
 *
 */

@Entity
@Data
public class AirPollutionComponents {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private String id;	
	
	private String co;
	private String no;
	private String no2;
	private String o3;
	private String so2;
	private String pm2_5;
	private String pm10;
	private String nh3;	
	
}
