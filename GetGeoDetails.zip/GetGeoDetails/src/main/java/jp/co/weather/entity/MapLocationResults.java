package jp.co.weather.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for map details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class MapLocationResults {
	@Id
	private String id;
	@OneToMany(cascade = CascadeType.ALL)
	private List<MapLocations> locations;
}
