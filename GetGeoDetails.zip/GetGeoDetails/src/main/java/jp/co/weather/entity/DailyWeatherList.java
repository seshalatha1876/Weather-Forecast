package jp.co.weather.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for daily weather details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class DailyWeatherList {	
	@Id 
	private String lat;	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Daily> daily;

}
