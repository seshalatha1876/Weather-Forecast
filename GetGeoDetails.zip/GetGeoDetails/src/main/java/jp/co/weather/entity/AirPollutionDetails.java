package jp.co.weather.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for air components
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class AirPollutionDetails {
	@Id
	private String dt;
	
	@OneToOne(cascade = CascadeType.ALL)
	private AirPollutionAQI main;
	
	@OneToOne(cascade = CascadeType.ALL)
	private AirPollutionComponents components;

}
