package jp.co.weather.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import jp.co.weather.entity.AirPollution;
import jp.co.weather.entity.DailyWeatherList;
import jp.co.weather.entity.GeoLocation;
import jp.co.weather.entity.MapLocations;
import jp.co.weather.entity.MapResults;
import jp.co.weather.exception.GeneralRestException;

/**
 * 
 * Weather forecast controller to get 
 * 1. location details based on postal code
 * 2. location map based on location 
 * 3. weather report for next 7 days that corresponds to longitude and latitude of postal code 
 * 4. air quality components and its pollution levels
 * 
 * @author sesha
 *
 */

@Controller
public class WeatherForecastController {

	private static final String GET_LOCATION_UPON_ZIP_CODE = "http://api.openweathermap.org/geo/1.0/zip?zip={zip code},{country code}&appid={API key}";

	private static final String GET_WEATHER_REPORT = "https://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude=current,minutely,hourly,alerts&units=metric&appid={API key}";

	private static final String GET_GEO_MAP = "http://www.mapquestapi.com/geocoding/v1/address?key={KEY}&location={location}";

	private static final String GET_CURRENT_AIR_POLLUTION = "http://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={API key}";

	private static final String COUNTRY_CODE = "JP";
	private static final String OPEN_WEATHER_API_KEY = "8905fafcea1582322acccf1af9fa75ad";
	private static final String MAP_QUEST_API_KEY = "oygAk3HMuycqZrTe2iuI8aGYmou5jpAd";

	private RestTemplate restTemplate = new RestTemplate();

	/*
	 * Initial page display
	 */
	@GetMapping("/")
	public String getZipCodeInfo(Model model) {
		model.addAttribute("location", new GeoLocation());
		return "GeoInfo";

	}

	/*
	 * Page display after submitting postal code to get 
	 * 1. location details based on postal code 
	 * 2. location map based on location 
	 * 3. weather report for next 7 days that corresponds to longitude and latitude of postal code
	 * 4. air quality components and its pollution levels
	 * 
	 * Also display error page in case of any incorrect postal code or bad request
	 */
	@PostMapping("/")
	public String getWeatherInfo(@ModelAttribute("location") GeoLocation geolocation, ModelMap model) {
		try {
			getLocationDetailsBasedOnZIP(geolocation.getPostCode().trim(), model);
			getDailyWeatherBasedOnLocation(model);
			getCurrentAirPollutionBasedOnLocation(model);
			getMapBasedOnLocation(model);
			return "GeoInfo";
		} catch (Exception e) {
			return "error";
		}
	}

	/*
	 * Get location details based on postal code
	 * 
	 * Exception in case of any incorrect postal code or bad request
	 */

	private void getLocationDetailsBasedOnZIP(String postCode, ModelMap model) throws Exception {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("zip code", postCode);
		paramMap.put("country code", COUNTRY_CODE);
		paramMap.put("API key", OPEN_WEATHER_API_KEY);
		GeoLocation geolocation = new GeoLocation();
		try {
			ResponseEntity<GeoLocation> locationResponse = restTemplate.getForEntity(GET_LOCATION_UPON_ZIP_CODE,
					GeoLocation.class, paramMap);
			geolocation = locationResponse.getBody();
			model.addAttribute("geolocation", geolocation);
		} catch (HttpStatusCodeException e) {
			model.addAttribute("errorMessage", e.getResponseBodyAsString());
			throw new GeneralRestException(e.getResponseBodyAsString());
		} catch (RestClientException e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		} catch (Exception e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		}
	}

	/*
	 * Get weather report for next 7 days that corresponds to longitude and latitude
	 * of postal code
	 * 
	 * Exception in case of any incorrect postal code or bad request
	 */
	private void getDailyWeatherBasedOnLocation(ModelMap model) throws Exception {
		GeoLocation geoLocation = (GeoLocation) model.get("geolocation");
		Map<String, String> weatherParam = new HashMap<>();
		weatherParam.put("lat", geoLocation.getLat());
		weatherParam.put("lon", geoLocation.getLon());
		weatherParam.put("API key", OPEN_WEATHER_API_KEY);

		try {
			ResponseEntity<DailyWeatherList> dailyWeatherReportResponse = restTemplate.getForEntity(GET_WEATHER_REPORT,
					DailyWeatherList.class, weatherParam);
			DailyWeatherList dailyWeatherReportList = dailyWeatherReportResponse.getBody();
			model.addAttribute("dailyWeatherReportList", dailyWeatherReportList.getDaily());
		} catch (HttpStatusCodeException e) {
			model.addAttribute("errorMessage", e.getResponseBodyAsString());
			throw new GeneralRestException(e.getResponseBodyAsString());
		} catch (RestClientException e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		} catch (Exception e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		}
	}

	/*
	 * Get air quality components and its pollution levels
	 * 
	 * Exception in case of any incorrect postal code or bad request
	 */
	private void getCurrentAirPollutionBasedOnLocation(ModelMap model) throws Exception {
		GeoLocation geoLocation = (GeoLocation) model.get("geolocation");
		Map<String, String> airPollutionParam = new HashMap<>();
		airPollutionParam.put("lat", geoLocation.getLat());
		airPollutionParam.put("lon", geoLocation.getLon());
		airPollutionParam.put("API key", OPEN_WEATHER_API_KEY);
		try {
			ResponseEntity<AirPollution> airPollutionParamResponse = restTemplate
					.getForEntity(GET_CURRENT_AIR_POLLUTION, AirPollution.class, airPollutionParam);
			model.addAttribute("airPollution", airPollutionParamResponse.getBody().getList());
		} catch (HttpStatusCodeException e) {
			model.addAttribute("errorMessage", e.getResponseBodyAsString());
			throw new GeneralRestException(e.getResponseBodyAsString());
		} catch (RestClientException e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		} catch (Exception e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		}
	}

	/*
	 * Get location map based on location
	 * 
	 * Exception in case of any incorrect postal code or bad request
	 */
	private void getMapBasedOnLocation(ModelMap model) throws Exception {
		GeoLocation geoLocation = (GeoLocation) model.get("geolocation");
		Map<String, String> geoParam = new HashMap<>();
		geoParam.put("KEY", MAP_QUEST_API_KEY);
		geoParam.put("location", geoLocation.getZip() + "+" + geoLocation.getName());
		try {
			ResponseEntity<MapResults> geoMapesponse = restTemplate.getForEntity(GET_GEO_MAP, MapResults.class,
					geoParam);
			List<MapLocations> locationsList = geoMapesponse.getBody().getResults().get(0).getLocations();
			model.addAttribute("mapURL", locationsList.get(0).getMapUrl());
			model.addAttribute("geomaplocation", locationsList.get(0));
		} catch (HttpStatusCodeException e) {
			model.addAttribute("errorMessage", e.getResponseBodyAsString());
			throw new GeneralRestException(e.getResponseBodyAsString());
		} catch (RestClientException e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		} catch (Exception e) {
			model.addAttribute("errorMessage", e.getMessage());
			throw new GeneralRestException(e.getMessage());
		}
	}

}
