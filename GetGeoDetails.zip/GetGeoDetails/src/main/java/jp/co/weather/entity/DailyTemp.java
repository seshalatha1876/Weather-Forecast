package jp.co.weather.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for daily weather details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class DailyTemp {
	@Id
	private String day;
	private String min;
	private String max;	
}
