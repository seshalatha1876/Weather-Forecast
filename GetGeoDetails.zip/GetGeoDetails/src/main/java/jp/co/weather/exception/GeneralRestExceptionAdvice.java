package jp.co.weather.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * GeneralRestExceptionAdvice to handle handle rest client exceptions, HTTP status exceptions and bad requests
 * 
 * @author sesha
 * 
 */
@ControllerAdvice
public class GeneralRestExceptionAdvice {

	@ResponseBody
	@ExceptionHandler(GeneralRestException.class)
	String generalRestException(GeneralRestException ex) {
		return ex.getMessage();
	}
}