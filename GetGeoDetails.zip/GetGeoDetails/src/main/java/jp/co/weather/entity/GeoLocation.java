package jp.co.weather.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for location details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GeoLocation {
	@Id
	private String postCode;
	private String zip;
	private String name;
	private String lat;
	private String lon;
	private String country; 
}
