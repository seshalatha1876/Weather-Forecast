package jp.co.weather.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for daily weather details 
 * 
 * @author sesha
 *
 */

@Data
@Entity
@NoArgsConstructor
public class Weather {
	@Id
	private String id;	
	private String main;	
	private String description;	
	private String icon;	
}
