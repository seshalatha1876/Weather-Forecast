package jp.co.weather.entity;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity for daily weather details 
 * 
 * @author sesha
 *
 */

@Entity
@Data
@NoArgsConstructor
public class Daily {
	@Id
	private long dt;
	
	private String date;   
	
	public String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd EEE", Locale.ENGLISH);		
		date = sdf.format(new Date(dt * 1000L));
		return date;
	}	
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Weather> weather;
	
	@OneToOne(cascade = CascadeType.ALL)
	private DailyTemp temp;
}
