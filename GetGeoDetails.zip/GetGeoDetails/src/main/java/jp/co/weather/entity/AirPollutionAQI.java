package jp.co.weather.entity;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

/**
 * Entity for air components
 * 
 * @author sesha
 *
 */

@Entity
@Data
public class AirPollutionAQI {
	@Id
	private int aqi;

	private String aqiStatus;

	public String getAqiStatus() {
		Map<Integer, String> pollutionStatus = new HashMap<>();
		pollutionStatus.put(1, "GOOD");
		pollutionStatus.put(2, "FAIR");
		pollutionStatus.put(3, "MODERATE");
		pollutionStatus.put(4, "POOR");
		pollutionStatus.put(5, "VERY POOR");
		this.aqiStatus = pollutionStatus.get(aqi);
		return pollutionStatus.get(aqi);
	}
}
